import React from 'react';
import { cn } from '../../utils/helpers';

export interface CheckboxProps {
  checked?: boolean;
  onChange?: (checked: boolean) => void;
  label?: string;
  disabled?: boolean;
  error?: string;
  className?: string;
}

export const Checkbox: React.FC<CheckboxProps> = ({
  checked = false,
  onChange,
  label,
  disabled = false,
  error,
  className,
}) => {
  const checkboxId = React.useId();

  return (
    <div className={cn('flex flex-col', className)}>
      <div className="flex items-center">
        <input
          id={checkboxId}
          type="checkbox"
          checked={checked}
          onChange={(e) => onChange?.(e.target.checked)}
          disabled={disabled}
          className={cn(
            'w-4 h-4 rounded border-neutral-300 text-primary-600',
            'focus:ring-2 focus:ring-primary-500 focus:ring-offset-2',
            'disabled:cursor-not-allowed disabled:opacity-50',
            'transition-colors cursor-pointer',
            error && 'border-danger-300'
          )}
        />
        {label && (
          <label
            htmlFor={checkboxId}
            className={cn(
              'ml-2 text-sm text-neutral-700 cursor-pointer select-none',
              disabled && 'cursor-not-allowed opacity-50'
            )}
          >
            {label}
          </label>
        )}
      </div>
      {error && <p className="mt-1 text-sm text-danger-600">{error}</p>}
    </div>
  );
};

Checkbox.displayName = 'Checkbox';
