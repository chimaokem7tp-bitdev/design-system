import type { Meta, StoryObj } from '@storybook/react';
import { Table } from './Table';
import { Badge } from '../Badge/Badge';

const meta = {
  title: 'Components/Table',
  component: Table,
  parameters: {
    layout: 'padded',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Table>;

export default meta;
type Story = StoryObj<typeof meta>;

const sampleData = [
  { id: 1, name: 'John Doe', email: 'john@example.com', status: 'Active', role: 'Admin' },
  { id: 2, name: 'Jane Smith', email: 'jane@example.com', status: 'Active', role: 'User' },
  { id: 3, name: 'Bob Johnson', email: 'bob@example.com', status: 'Inactive', role: 'User' },
  { id: 4, name: 'Alice Williams', email: 'alice@example.com', status: 'Active', role: 'Manager' },
  { id: 5, name: 'Charlie Brown', email: 'charlie@example.com', status: 'Pending', role: 'User' },
];

const basicColumns = [
  { key: 'id', label: 'ID', sortable: true },
  { key: 'name', label: 'Name', sortable: true },
  { key: 'email', label: 'Email', sortable: true },
  { key: 'status', label: 'Status', sortable: true },
  { key: 'role', label: 'Role', sortable: true },
];

export const Default: Story = {
  args: {
    columns: basicColumns,
    data: sampleData,
  },
};

export const WithCustomRender: Story = {
  args: {
    columns: [
      { key: 'id', label: 'ID', sortable: true, width: '16' },
      { key: 'name', label: 'Name', sortable: true },
      { key: 'email', label: 'Email', sortable: true },
      {
        key: 'status',
        label: 'Status',
        sortable: true,
        render: (value: string) => (
          <Badge
            variant={
              value === 'Active'
                ? 'success'
                : value === 'Inactive'
                ? 'danger'
                : 'warning'
            }
            size="sm"
          >
            {value}
          </Badge>
        ),
      },
      { key: 'role', label: 'Role', sortable: true },
    ],
    data: sampleData,
  },
};

export const Striped: Story = {
  args: {
    columns: basicColumns,
    data: sampleData,
    striped: true,
  },
};

export const WithRowClick: Story = {
  args: {
    columns: basicColumns,
    data: sampleData,
    onRowClick: (row) => alert(`Clicked on ${row.name}`),
  },
};

export const Loading: Story = {
  args: {
    columns: basicColumns,
    data: sampleData,
    loading: true,
  },
};

export const EmptyState: Story = {
  args: {
    columns: basicColumns,
    data: [],
  },
};
