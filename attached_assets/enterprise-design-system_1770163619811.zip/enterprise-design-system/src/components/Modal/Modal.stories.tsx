import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';
import { Modal, ModalFooter } from './Modal';
import { Button } from '../Button/Button';

const meta = {
  title: 'Components/Modal',
  component: Modal,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Modal>;

export default meta;
type Story = StoryObj<typeof meta>;

const ModalWithButton = (args: any) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <Button onClick={() => setIsOpen(true)}>Open Modal</Button>
      <Modal {...args} isOpen={isOpen} onClose={() => setIsOpen(false)} />
    </>
  );
};

export const Default: Story = {
  render: (args) => <ModalWithButton {...args} />,
  args: {
    title: 'Modal Title',
    children: (
      <div>
        <p className="text-neutral-700">
          This is a modal dialog. You can put any content here.
        </p>
      </div>
    ),
  },
};

export const WithFooter: Story = {
  render: (args) => <ModalWithButton {...args} />,
  args: {
    title: 'Confirm Action',
    children: (
      <>
        <div>
          <p className="text-neutral-700">
            Are you sure you want to perform this action? This cannot be undone.
          </p>
        </div>
        <ModalFooter>
          <Button variant="ghost">Cancel</Button>
          <Button variant="danger">Delete</Button>
        </ModalFooter>
      </>
    ),
  },
};

export const Small: Story = {
  render: (args) => <ModalWithButton {...args} />,
  args: {
    title: 'Small Modal',
    size: 'sm',
    children: (
      <div>
        <p className="text-neutral-700">This is a small modal.</p>
      </div>
    ),
  },
};

export const Large: Story = {
  render: (args) => <ModalWithButton {...args} />,
  args: {
    title: 'Large Modal',
    size: 'lg',
    children: (
      <div>
        <p className="text-neutral-700 mb-4">This is a large modal with more content.</p>
        <p className="text-neutral-700">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod
          tempor incididunt ut labore et dolore magna aliqua.
        </p>
      </div>
    ),
  },
};

export const FormModal: Story = {
  render: (args) => <ModalWithButton {...args} />,
  args: {
    title: 'Create New User',
    children: (
      <>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1.5">
              Full Name
            </label>
            <input
              type="text"
              className="w-full px-4 py-2.5 rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
              placeholder="Enter full name"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1.5">
              Email
            </label>
            <input
              type="email"
              className="w-full px-4 py-2.5 rounded-lg border border-neutral-300 focus:outline-none focus:ring-2 focus:ring-primary-500"
              placeholder="Enter email address"
            />
          </div>
        </div>
        <ModalFooter>
          <Button variant="ghost">Cancel</Button>
          <Button>Create User</Button>
        </ModalFooter>
      </>
    ),
  },
};
