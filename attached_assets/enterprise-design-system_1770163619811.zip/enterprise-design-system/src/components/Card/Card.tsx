import React from 'react';
import { cn } from '../../utils/helpers';
import { CardProps } from '../../types';

const cardVariants = {
  elevated: 'bg-white shadow-md',
  outlined: 'bg-white border-2 border-neutral-200',
  filled: 'bg-neutral-50 border border-neutral-200',
};

const cardPadding = {
  xs: 'p-2',
  sm: 'p-3',
  md: 'p-4',
  lg: 'p-6',
  xl: 'p-8',
};

export const Card: React.FC<CardProps> = ({
  variant = 'elevated',
  padding = 'md',
  hoverable = false,
  children,
  className,
  ...props
}) => {
  return (
    <div
      className={cn(
        'rounded-lg transition-base',
        cardVariants[variant],
        cardPadding[padding],
        hoverable && 'cursor-pointer hover:shadow-lg hover:scale-[1.02]',
        className
      )}
      {...props}
    >
      {children}
    </div>
  );
};

Card.displayName = 'Card';

// Card subcomponents
export const CardHeader: React.FC<{ children: React.ReactNode; className?: string }> = ({
  children,
  className,
}) => (
  <div className={cn('mb-4', className)}>{children}</div>
);

CardHeader.displayName = 'CardHeader';

export const CardTitle: React.FC<{ children: React.ReactNode; className?: string }> = ({
  children,
  className,
}) => (
  <h3 className={cn('text-lg font-semibold text-neutral-900', className)}>
    {children}
  </h3>
);

CardTitle.displayName = 'CardTitle';

export const CardDescription: React.FC<{ children: React.ReactNode; className?: string }> = ({
  children,
  className,
}) => (
  <p className={cn('text-sm text-neutral-600 mt-1', className)}>{children}</p>
);

CardDescription.displayName = 'CardDescription';

export const CardContent: React.FC<{ children: React.ReactNode; className?: string }> = ({
  children,
  className,
}) => (
  <div className={cn(className)}>{children}</div>
);

CardContent.displayName = 'CardContent';

export const CardFooter: React.FC<{ children: React.ReactNode; className?: string }> = ({
  children,
  className,
}) => (
  <div className={cn('mt-4 flex items-center gap-2', className)}>{children}</div>
);

CardFooter.displayName = 'CardFooter';
