import type { Meta, StoryObj } from '@storybook/react';
import { Avatar, AvatarGroup } from './Avatar';

const meta = {
  title: 'Components/Avatar',
  component: Avatar,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
} satisfies Meta<typeof Avatar>;

export default meta;
type Story = StoryObj<typeof meta>;

export const WithImage: Story = {
  args: {
    src: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400',
    alt: 'User avatar',
  },
};

export const WithInitials: Story = {
  args: {
    name: 'John Doe',
  },
};

export const ColorVariants: Story = {
  render: () => (
    <div className="flex gap-3">
      <Avatar name="John Doe" color="primary" />
      <Avatar name="Jane Smith" color="secondary" />
      <Avatar name="Bob Johnson" color="success" />
      <Avatar name="Alice Williams" color="warning" />
      <Avatar name="Charlie Brown" color="danger" />
    </div>
  ),
};

export const Sizes: Story = {
  render: () => (
    <div className="flex items-center gap-3">
      <Avatar name="JD" size="xs" />
      <Avatar name="JD" size="sm" />
      <Avatar name="JD" size="md" />
      <Avatar name="JD" size="lg" />
      <Avatar name="JD" size="xl" />
    </div>
  ),
};

export const Group: Story = {
  render: () => (
    <AvatarGroup max={3}>
      <Avatar src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400" />
      <Avatar name="Jane Smith" color="secondary" />
      <Avatar name="Bob Johnson" color="success" />
      <Avatar name="Alice Williams" color="warning" />
      <Avatar name="Charlie Brown" color="danger" />
    </AvatarGroup>
  ),
};

export const FallbackOnError: Story = {
  args: {
    src: 'https://invalid-url.com/image.jpg',
    name: 'Fallback User',
  },
};
