import React from 'react';
import { cn, getInitials } from '../../utils/helpers';
import { AvatarProps } from '../../types';

const avatarSizes = {
  xs: 'w-6 h-6 text-xs',
  sm: 'w-8 h-8 text-sm',
  md: 'w-10 h-10 text-base',
  lg: 'w-12 h-12 text-lg',
  xl: 'w-16 h-16 text-xl',
};

const avatarColors = {
  primary: 'bg-primary-100 text-primary-700',
  secondary: 'bg-secondary-100 text-secondary-700',
  success: 'bg-success-100 text-success-700',
  warning: 'bg-warning-100 text-warning-700',
  danger: 'bg-danger-100 text-danger-700',
  neutral: 'bg-neutral-200 text-neutral-700',
};

export const Avatar: React.FC<AvatarProps> = ({
  src,
  alt,
  size = 'md',
  name,
  color = 'neutral',
  className,
  ...props
}) => {
  const [imageError, setImageError] = React.useState(false);
  const initials = name ? getInitials(name) : '';

  return (
    <div
      className={cn(
        'relative inline-flex items-center justify-center rounded-full overflow-hidden flex-shrink-0',
        avatarSizes[size],
        !src || imageError ? avatarColors[color] : 'bg-neutral-200',
        className
      )}
      {...props}
    >
      {src && !imageError ? (
        <img
          src={src}
          alt={alt || name || 'Avatar'}
          className="w-full h-full object-cover"
          onError={() => setImageError(true)}
        />
      ) : (
        <span className="font-semibold">{initials || '?'}</span>
      )}
    </div>
  );
};

Avatar.displayName = 'Avatar';

// Avatar Group component
export const AvatarGroup: React.FC<{
  children: React.ReactNode;
  max?: number;
  className?: string;
}> = ({ children, max = 3, className }) => {
  const childrenArray = React.Children.toArray(children);
  const displayedChildren = max ? childrenArray.slice(0, max) : childrenArray;
  const remaining = childrenArray.length - displayedChildren.length;

  return (
    <div className={cn('flex -space-x-2', className)}>
      {displayedChildren.map((child, index) => (
        <div key={index} className="ring-2 ring-white rounded-full">
          {child}
        </div>
      ))}
      {remaining > 0 && (
        <div className="ring-2 ring-white rounded-full">
          <div className="w-10 h-10 rounded-full bg-neutral-200 text-neutral-700 flex items-center justify-center text-sm font-semibold">
            +{remaining}
          </div>
        </div>
      )}
    </div>
  );
};

AvatarGroup.displayName = 'AvatarGroup';
