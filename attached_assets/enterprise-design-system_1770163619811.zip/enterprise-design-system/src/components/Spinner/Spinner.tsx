import React from 'react';
import { cn } from '../../utils/helpers';
import { Size, ColorScheme } from '../../types';

export interface SpinnerProps {
  size?: Size;
  color?: ColorScheme;
  className?: string;
}

const spinnerSizes = {
  xs: 'w-4 h-4',
  sm: 'w-5 h-5',
  md: 'w-8 h-8',
  lg: 'w-12 h-12',
  xl: 'w-16 h-16',
};

const spinnerColors = {
  primary: 'border-primary-600',
  secondary: 'border-secondary-600',
  success: 'border-success-600',
  warning: 'border-warning-600',
  danger: 'border-danger-600',
  neutral: 'border-neutral-600',
};

export const Spinner: React.FC<SpinnerProps> = ({
  size = 'md',
  color = 'primary',
  className,
}) => {
  return (
    <div
      className={cn(
        'inline-block border-4 border-neutral-200 border-t-transparent rounded-full animate-spin',
        spinnerSizes[size],
        spinnerColors[color],
        className
      )}
      role="status"
      aria-label="Loading"
    >
      <span className="sr-only">Loading...</span>
    </div>
  );
};

Spinner.displayName = 'Spinner';
