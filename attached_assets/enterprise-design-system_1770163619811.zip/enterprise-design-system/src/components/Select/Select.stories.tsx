import type { Meta, StoryObj } from '@storybook/react';
import { Select } from './Select';

const meta = {
  title: 'Components/Select',
  component: Select,
  parameters: {
    layout: 'centered',
  },
  tags: ['autodocs'],
  decorators: [
    (Story) => (
      <div style={{ width: '400px' }}>
        <Story />
      </div>
    ),
  ],
} satisfies Meta<typeof Select>;

export default meta;
type Story = StoryObj<typeof meta>;

const options = [
  { label: 'Option 1', value: '1' },
  { label: 'Option 2', value: '2' },
  { label: 'Option 3', value: '3' },
  { label: 'Option 4', value: '4' },
  { label: 'Disabled Option', value: '5', disabled: true },
];

export const Default: Story = {
  args: {
    options,
    placeholder: 'Choose an option',
  },
};

export const WithLabel: Story = {
  args: {
    label: 'Select Option',
    options,
    placeholder: 'Choose an option',
  },
};

export const WithValue: Story = {
  args: {
    label: 'Country',
    options: [
      { label: 'United States', value: 'us' },
      { label: 'Canada', value: 'ca' },
      { label: 'United Kingdom', value: 'uk' },
      { label: 'Australia', value: 'au' },
    ],
    value: 'us',
  },
};

export const WithError: Story = {
  args: {
    label: 'Required Field',
    options,
    error: 'This field is required',
  },
};

export const Disabled: Story = {
  args: {
    label: 'Disabled Select',
    options,
    disabled: true,
  },
};

export const Small: Story = {
  args: {
    options,
    size: 'sm',
  },
};

export const Large: Story = {
  args: {
    options,
    size: 'lg',
  },
};
