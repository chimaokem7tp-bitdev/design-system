import React, { useState } from 'react';
import {
  Button,
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
  CardFooter,
  Input,
  Select,
  Checkbox,
  Badge,
  Avatar,
  AvatarGroup,
  Modal,
  ModalFooter,
  Table,
  Alert,
  Spinner,
  Tooltip,
} from './index';

/**
 * Example application demonstrating the Enterprise Design System
 * This shows how to use components together in a real application
 */
export const ExampleApp: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    country: '',
    acceptTerms: false,
  });
  const [showAlert, setShowAlert] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  const countries = [
    { label: 'United States', value: 'us' },
    { label: 'Canada', value: 'ca' },
    { label: 'United Kingdom', value: 'uk' },
    { label: 'Australia', value: 'au' },
  ];

  const userData = [
    {
      id: 1,
      name: 'John Doe',
      email: 'john@example.com',
      role: 'Admin',
      status: 'Active',
    },
    {
      id: 2,
      name: 'Jane Smith',
      email: 'jane@example.com',
      role: 'User',
      status: 'Active',
    },
    {
      id: 3,
      name: 'Bob Johnson',
      email: 'bob@example.com',
      role: 'Manager',
      status: 'Inactive',
    },
  ];

  const columns = [
    { key: 'id', label: 'ID', sortable: true, width: '16' },
    { key: 'name', label: 'Name', sortable: true },
    { key: 'email', label: 'Email', sortable: true },
    { key: 'role', label: 'Role', sortable: true },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
      render: (value: string) => (
        <Badge variant={value === 'Active' ? 'success' : 'danger'} size="sm">
          {value}
        </Badge>
      ),
    },
  ];

  const handleSubmit = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      setIsModalOpen(false);
      alert('Form submitted successfully!');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-neutral-50 p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-neutral-900 mb-2">
              Enterprise Design System
            </h1>
            <p className="text-neutral-600">
              A comprehensive component library example
            </p>
          </div>
          <AvatarGroup max={3}>
            <Avatar name="John Doe" color="primary" />
            <Avatar name="Jane Smith" color="secondary" />
            <Avatar name="Bob Johnson" color="success" />
            <Avatar name="Alice Williams" color="warning" />
          </AvatarGroup>
        </div>

        {/* Alert */}
        {showAlert && (
          <Alert
            variant="info"
            title="Welcome!"
            onClose={() => setShowAlert(false)}
          >
            This is an example application showcasing all components in the design
            system.
          </Alert>
        )}

        {/* Action Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card variant="elevated" hoverable>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
              <CardDescription>Common tasks and actions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <Button variant="primary" fullWidth onClick={() => setIsModalOpen(true)}>
                  Create New User
                </Button>
                <Button variant="outline" fullWidth>
                  Export Data
                </Button>
                <Tooltip content="This action requires admin privileges" position="right">
                  <Button variant="ghost" fullWidth disabled>
                    Admin Settings
                  </Button>
                </Tooltip>
              </div>
            </CardContent>
          </Card>

          <Card variant="outlined">
            <CardHeader>
              <CardTitle>Statistics</CardTitle>
              <CardDescription>System overview</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-neutral-600">Total Users</span>
                  <Badge variant="primary">1,234</Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-neutral-600">Active Sessions</span>
                  <Badge variant="success" dot>
                    456
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-neutral-600">Pending Tasks</span>
                  <Badge variant="warning">89</Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card variant="filled">
            <CardHeader>
              <CardTitle>System Status</CardTitle>
              <CardDescription>All systems operational</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success-500 rounded-full animate-pulse" />
                  <span className="text-sm">API Server</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success-500 rounded-full animate-pulse" />
                  <span className="text-sm">Database</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-success-500 rounded-full animate-pulse" />
                  <span className="text-sm">Cache</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* User Table */}
        <Card>
          <CardHeader>
            <CardTitle>User Management</CardTitle>
            <CardDescription>Manage and view all users</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <Table
              columns={columns}
              data={userData}
              striped
              hoverable
              onRowClick={(row) => alert(`Viewing ${row.name}`)}
            />
          </CardContent>
        </Card>

        {/* Create User Modal */}
        <Modal
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
          title="Create New User"
          size="md"
        >
          <div className="space-y-4">
            <Input
              label="Full Name"
              placeholder="Enter full name"
              value={formData.name}
              onChange={(e) =>
                setFormData({ ...formData, name: e.target.value })
              }
              required
            />
            <Input
              label="Email Address"
              type="email"
              placeholder="you@example.com"
              value={formData.email}
              onChange={(e) =>
                setFormData({ ...formData, email: e.target.value })
              }
              required
            />
            <Select
              label="Country"
              options={countries}
              value={formData.country}
              onChange={(value) =>
                setFormData({ ...formData, country: value })
              }
              placeholder="Select country"
            />
            <Checkbox
              label="I accept the terms and conditions"
              checked={formData.acceptTerms}
              onChange={(checked) =>
                setFormData({ ...formData, acceptTerms: checked })
              }
            />
          </div>
          <ModalFooter>
            <Button
              variant="ghost"
              onClick={() => setIsModalOpen(false)}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              onClick={handleSubmit}
              loading={isLoading}
              disabled={!formData.acceptTerms}
            >
              Create User
            </Button>
          </ModalFooter>
        </Modal>

        {/* Loading State Example */}
        <Card>
          <CardHeader>
            <CardTitle>Loading States</CardTitle>
            <CardDescription>Various loading indicators</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <Spinner size="sm" color="primary" />
              <Spinner size="md" color="secondary" />
              <Spinner size="lg" color="success" />
              <Button variant="primary" loading>
                Loading Button
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ExampleApp;
