import type { Meta } from '@storybook/react';

const meta = {
  title: 'Introduction',
  parameters: {
    docs: {
      page: () => (
        <div className="prose max-w-4xl mx-auto p-8">
          <h1 className="text-4xl font-bold mb-4">Enterprise Design System</h1>
          
          <p className="text-lg text-neutral-600 mb-8">
            A comprehensive, accessible, and customizable component library for building
            enterprise applications with React, TypeScript, and Tailwind CSS.
          </p>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-4">Getting Started</h2>
            <p className="mb-4">
              This design system provides a complete set of reusable components that follow
              best practices for accessibility, performance, and user experience.
            </p>
            
            <div className="bg-neutral-100 p-4 rounded-lg mb-4">
              <code className="text-sm">
                npm install enterprise-design-system
              </code>
            </div>

            <pre className="bg-neutral-900 text-white p-4 rounded-lg overflow-x-auto">
              <code>{`import { Button, Card, Input } from 'enterprise-design-system';

function App() {
  return (
    <Card>
      <Input label="Email" type="email" />
      <Button variant="primary">Submit</Button>
    </Card>
  );
}`}</code>
            </pre>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-4">Features</h2>
            <ul className="list-disc list-inside space-y-2 text-neutral-700">
              <li>🎨 <strong>12 Core Components</strong> - Comprehensive component library</li>
              <li>🎯 <strong>TypeScript</strong> - Full type safety and IntelliSense</li>
              <li>🌈 <strong>Tailwind CSS</strong> - Utility-first styling</li>
              <li>📚 <strong>Storybook</strong> - Interactive documentation</li>
              <li>♿ <strong>Accessible</strong> - ARIA compliant</li>
              <li>🎭 <strong>Variants</strong> - Multiple styles and sizes</li>
              <li>🎨 <strong>Themeable</strong> - Customizable design tokens</li>
              <li>📱 <strong>Responsive</strong> - Mobile-first approach</li>
            </ul>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-4">Components</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {[
                'Button',
                'Input',
                'Card',
                'Badge',
                'Avatar',
                'Modal',
                'Table',
                'Select',
                'Checkbox',
                'Tooltip',
                'Spinner',
                'Alert',
              ].map((component) => (
                <div
                  key={component}
                  className="p-4 border border-neutral-200 rounded-lg hover:shadow-md transition-shadow"
                >
                  <h3 className="font-semibold text-neutral-900">{component}</h3>
                </div>
              ))}
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-4">Design Tokens</h2>
            <p className="mb-4">
              Our design system uses a carefully crafted set of design tokens for consistency:
            </p>
            
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Colors</h3>
                <div className="flex gap-2 flex-wrap">
                  <div className="w-16 h-16 bg-primary-500 rounded-lg" title="Primary" />
                  <div className="w-16 h-16 bg-secondary-500 rounded-lg" title="Secondary" />
                  <div className="w-16 h-16 bg-success-500 rounded-lg" title="Success" />
                  <div className="w-16 h-16 bg-warning-500 rounded-lg" title="Warning" />
                  <div className="w-16 h-16 bg-danger-500 rounded-lg" title="Danger" />
                  <div className="w-16 h-16 bg-neutral-500 rounded-lg" title="Neutral" />
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Typography</h3>
                <div className="space-y-2">
                  <p className="text-xs">Extra Small - 12px</p>
                  <p className="text-sm">Small - 14px</p>
                  <p className="text-base">Base - 16px</p>
                  <p className="text-lg">Large - 18px</p>
                  <p className="text-xl">Extra Large - 20px</p>
                </div>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Spacing</h3>
                <p className="text-neutral-600">
                  Following Tailwind's spacing scale: 0.25rem increments (4px base)
                </p>
              </div>
            </div>
          </section>

          <section className="mb-12">
            <h2 className="text-2xl font-semibold mb-4">Best Practices</h2>
            <ol className="list-decimal list-inside space-y-3 text-neutral-700">
              <li>
                <strong>Use semantic variants</strong> - Choose variants that match the
                action's meaning (success for positive actions, danger for destructive ones)
              </li>
              <li>
                <strong>Maintain consistency</strong> - Use the same component variants and
                sizes throughout your application
              </li>
              <li>
                <strong>Consider accessibility</strong> - Ensure proper color contrast and
                keyboard navigation
              </li>
              <li>
                <strong>Responsive design</strong> - Test components on different screen sizes
              </li>
              <li>
                <strong>Performance</strong> - Import only the components you need for better
                tree-shaking
              </li>
            </ol>
          </section>

          <section>
            <h2 className="text-2xl font-semibold mb-4">Support</h2>
            <p className="text-neutral-700">
              For questions, issues, or contributions, please visit our GitHub repository
              or contact the design systems team.
            </p>
          </section>
        </div>
      ),
    },
  },
} satisfies Meta;

export default meta;

export const Page = {
  render: () => null,
};
