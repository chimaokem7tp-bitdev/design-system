import type { Meta, StoryObj } from '@storybook/react';
import ExampleApp from './ExampleApp';

const meta = {
  title: 'Examples/Full Application',
  component: ExampleApp,
  parameters: {
    layout: 'fullscreen',
  },
} satisfies Meta<typeof ExampleApp>;

export default meta;
type Story = StoryObj<typeof meta>;

export const CompleteApplication: Story = {};
